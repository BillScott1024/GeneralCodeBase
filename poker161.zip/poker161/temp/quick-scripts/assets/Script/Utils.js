(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Utils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd5011sdGuxPWoZ5ibb7n2TX', 'Utils', __filename);
// Script/Utils.js

'use strict';

cocosAnalytics.init({
    appID: '13798',
    appSecret: '959b3ac0037d0f3c2fdce94f8421a9b2',
    channel: '000000',
    version: '1.6.2'
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Utils.js.map
        