cocosAnalytics.init({
    appID: '13798',
    appSecret: '959b3ac0037d0f3c2fdce94f8421a9b2',
    channel: '000000',
    version: '1.6.2'
});